from sqlalchemy.orm import Session

from app.dao.hospital_dao import HospitalDAO


class HospitalService:
    def __init__(self,db:Session):
        self.dao = HospitalDAO(db)

    def get_hospital(self, hospital):
        res = self.dao.find_by_name(hospital)
        return res
