from fastapi import APIRouter
from fastapi.params import Depends
from sqlalchemy.orm import Session

from app.service.hospital.hospital_service import HospitalService
from app.util.database_util import get_db

router=  APIRouter()

def get_hospital_service(db: Session=Depends(get_db)):
    return HospitalService(db)


# 내 병원에 조회
@router.get("/hospital/{hospital_name}")
def get_hospital(hospital_name:str,
                 service:HospitalService = Depends(get_hospital_service)
                 ):
    print(hospital_name)
    res = service.get_hospital(hospital_name)

    return res
